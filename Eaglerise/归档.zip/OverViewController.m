//
//  OverViewController.m
//  Eaglerise
//
//  Created by Evan on 15/10/30.
//  Copyright © 2015年 Eaglerise. All rights reserved.
//

#import "OverViewController.h"
#import "JXBarChartView.h"
#define channelOnPeropheralView @"OverView"
@interface OverViewController ()<UIScrollViewDelegate,CBCentralManagerDelegate,CBPeripheralDelegate,CBPeripheralManagerDelegate>
{
    NSMutableArray *textIndicators;
    UILabel * popLbl;
    int week;
    int time;
    AppDelegate * mydelegate;
    NSUserDefaults *userdefaults;
}
@property (nonatomic,strong) UILabel * popLbl;
@property (nonatomic,strong) UIScrollView * contentSView;
@property (nonatomic,strong) UIButton * okBtn;
@property (nonatomic,strong) UISlider * slider;
@property (nonatomic,strong)CBCharacteristic *characteristic;
@end

@implementation OverViewController
@synthesize popLbl;
@synthesize contentSView;
@synthesize okBtn;
@synthesize slider;


-(id)init{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadDataAction:) name:@"loadOverView" object:nil];
        
        mydelegate=(AppDelegate*)[[UIApplication sharedApplication]delegate];
        userdefaults = [NSUserDefaults standardUserDefaults];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
     self.view.backgroundColor = [UIColor whiteColor];

    [self iv];
    [self lc];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.currPeripheral = mydelegate.currPeripheral;
    self->baby  = mydelegate.baby;
    self.characteristic = [mydelegate.characteristics objectAtIndex:1];
    //设置蓝牙委托
    [self babyDelegate];

}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if (self.currPeripheral != nil && self.characteristic != nil) {
        [self loadAction];
    }
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
   
    }

#pragma mark --
#pragma mark - 初始化页面元素
/**
 *初始化参数
 */
-(void)iv
{
     textIndicators = [[NSMutableArray alloc] initWithObjects:@"channel 1", @"channel 2", @"channel 3", nil];
    
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *now;
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit |
    NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit;
    now=[NSDate date];
    comps = [calendar components:unitFlags fromDate:now];
    week = (int)[comps weekday];
}

/**
 *加载控件
 */
-(void)lc
{
    contentSView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, Drive_Wdith, Drive_Height-100)];
    [contentSView setBackgroundColor:[UIColor whiteColor]];
//    contentSView.pagingEnabled = YES;
    contentSView.delegate = self;
    contentSView.showsVerticalScrollIndicator = NO;
    contentSView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:contentSView];
    

    NSMutableArray *values = [[NSMutableArray alloc] initWithObjects:@([[NSUserDefaults standardUserDefaults] objectForKey:@"slider1"] ==nil?100:[[[NSUserDefaults standardUserDefaults] objectForKey:@"slider1"]intValue]), @([[NSUserDefaults standardUserDefaults] objectForKey:@"slider2"] ==nil?100:[[[NSUserDefaults standardUserDefaults] objectForKey:@"slider2"]intValue]), @([[NSUserDefaults standardUserDefaults] objectForKey:@"slider3"] ==nil?100:[[[NSUserDefaults standardUserDefaults] objectForKey:@"slider3"]intValue]), nil];
//     NSMutableArray *values = [[NSMutableArray alloc] initWithObjects:@5.4,@6,@7, nil];
//    [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"slider%ld",indexPath.row+1]] ==nil?100:[[[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"slider%ld",indexPath.row+1]]intValue];

    
    CGRect frame = CGRectMake(10, 0, Drive_Wdith-20, 150);

    JXBarChartView *barChartView = [[JXBarChartView alloc] initWithFrame:frame
                                                              startPoint:CGPointMake(20, 20)
                                                                  values:values maxValue:10
                                                          textIndicators:textIndicators
                                                               textColor:[UIColor colorWithRed:(float)135/255.0 green:(float)135/255.0 blue:(float)135/255.0 alpha:1.0f]
                                                               barHeight:30
                                                             barMaxWidth:Drive_Wdith<321?(Drive_Wdith/5*3-50):(Drive_Wdith/5*3)
                                                                gradient:nil];
    [contentSView addSubview:barChartView];
    
    UILabel * Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 190, Drive_Wdith-60, 1.5)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 196, 70, 30)];
    Lbl.text = @"Time";
    Lbl.backgroundColor = [UIColor clearColor];
    [Lbl setTextAlignment:NSTextAlignmentLeft];
    [Lbl setTextColor:[UIColor colorWithRed:(float)135/255.0 green:(float)135/255.0 blue:(float)135/255.0 alpha:1.0f]];
    [Lbl setFont:[UIFont boldSystemFontOfSize:16]];
    [contentSView addSubview:Lbl];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 226, Drive_Wdith-60, 1.5)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 250, 40, 30)];
    Lbl.text = @"0";
    Lbl.backgroundColor = [UIColor clearColor];
    [Lbl setTextAlignment:NSTextAlignmentLeft];
    [Lbl setTextColor:[UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f]];
    [Lbl setFont:[UIFont boldSystemFontOfSize:16]];
    [contentSView addSubview:Lbl];
    
    slider = [[UISlider alloc] initWithFrame:CGRectMake(40, 255, Drive_Wdith-100, 20)];
    slider.minimumValue = 0;
    slider.maximumValue = 36;
    slider.minimumTrackTintColor = [UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f];
    slider.thumbTintColor = [UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f];
    slider.maximumTrackTintColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    slider.value = 12;

    [slider addTarget:self action:@selector(updateValue:) forControlEvents:UIControlEventValueChanged];

    [contentSView addSubview:slider];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(Drive_Wdith-60, 250, 40, 30)];
    Lbl.text = @"36";
    Lbl.backgroundColor = [UIColor clearColor];
    [Lbl setTextAlignment:NSTextAlignmentLeft];
    [Lbl setTextColor:[UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f]];
    [Lbl setFont:[UIFont boldSystemFontOfSize:16]];
    [contentSView addSubview:Lbl];
    
    popLbl = [[UILabel alloc]initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y-10, 70, 20)];
    [popLbl setTextAlignment:NSTextAlignmentCenter];
    [popLbl setBackgroundColor:[UIColor clearColor]];
//    [popLbl setAlpha:0.f];
    [contentSView addSubview:popLbl];
    
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 300, Drive_Wdith-60, 1.5)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 306, 70, 30)];
    Lbl.text = @"Week";
    Lbl.backgroundColor = [UIColor clearColor];
    [Lbl setTextAlignment:NSTextAlignmentLeft];
    [Lbl setTextColor:[UIColor colorWithRed:(float)135/255.0 green:(float)135/255.0 blue:(float)135/255.0 alpha:1.0f]];
    [Lbl setFont:[UIFont boldSystemFontOfSize:16]];
    [contentSView addSubview:Lbl];
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 340, Drive_Wdith-60, 1.5)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];
    
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(50, 400, Drive_Wdith-100, 3)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];

    float lenght = (Drive_Wdith-205)/6+15;
    
   
    
    
    for (int i = 0; i<7; i++) {
        Lbl = [[UILabel alloc]initWithFrame:CGRectMake(50+lenght*i, 393.5, 15, 15)];
        
        Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
        [Lbl.layer setCornerRadius:CGRectGetHeight([Lbl bounds]) / 2];
        [Lbl.layer setMasksToBounds:YES];
        [Lbl.layer setBorderWidth:2];
        [Lbl.layer setBorderColor:[UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f].CGColor];
        if (week-1 == 0) {
            week = 7;
        }
        if (i == (week-1)) {
            Lbl.backgroundColor = [UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f];
            [Lbl.layer setBorderColor:[UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f].CGColor];
        }
        [contentSView addSubview:Lbl];
        
        if (i==0 || i%2==0) {
            if (i==2) {
                Lbl = [[UILabel alloc]initWithFrame:CGRectMake(15+lenght*i, 370, lenght*2, 20)];
            }
            else
            {
            Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30+lenght*i, 370, lenght*2, 20)];
            }
            
           
        }
        else
        {
            Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30+lenght*i, 410, lenght*2, 20)];
        }
        Lbl.textAlignment = NSTextAlignmentLeft;
        Lbl.backgroundColor = [UIColor clearColor];
        Lbl.textColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
        [contentSView addSubview:Lbl];
        switch (i) {
            case 0:
                Lbl.text = @"Monday";
                break;
            case 1:
                Lbl.text = @"Tuesday";
                
                break;
            case 2:
                Lbl.text = @"Wednesday";
                break;
            case 3:
                Lbl.text = @"Thursday";
                break;
            case 4:
                Lbl.text = @"Friday";
                break;
            case 5:
                Lbl.text = @"Saturday";
                break;
            case 6:
                Lbl.text = @"Sunday";
                break;
                
            default:
                break;
        }
        if (week-1 == 0) {
            week = 7;
        }
        if (i == (week -1)) {
            Lbl.textColor = [UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f];
        }
        if (Drive_Wdith <= 320) {
            [Lbl setFont:[UIFont systemFontOfSize:12]];
        }
//        NSLog(@"%f",Drive_Wdith);
    }
    
    Lbl = [[UILabel alloc]initWithFrame:CGRectMake(30, 450, Drive_Wdith-60, 1.5)];
    
    Lbl.backgroundColor = [UIColor colorWithRed:(float)202/255.0 green:(float)202/255.0 blue:(float)202/255.0 alpha:1.0f];
    [contentSView addSubview:Lbl];
    
    
    okBtn = [[UIButton alloc]initWithFrame:CGRectMake(Drive_Wdith/4, 500, Drive_Wdith/2, 35)];
    
    [okBtn setBackgroundColor:[UIColor colorWithRed:(float)10/255.0 green:(float)182/255.0 blue:(float)248/255.0 alpha:1.0f]];
    [okBtn setTitle:@"Auto Play" forState:UIControlStateNormal];
    [okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //    [okBtn.titleLabel setFont:[UIFont systemFontOfSize:18]];
    [okBtn addTarget:self action:@selector(StartAction) forControlEvents:UIControlEventTouchUpInside];
    
    [okBtn.layer setMasksToBounds:YES];
    
    [okBtn.layer setCornerRadius:4.0];
    
    [contentSView addSubview:okBtn];
    
    contentSView.contentSize = CGSizeMake(Drive_Wdith, 570);
    
}


-(void)updateValue:(id)sender{
    
    UISlider * slider = (UISlider *)sender;
    float f = slider.value; //读取滑块的值
    time = slider.value;
    UIImageView *imageView = [slider.subviews objectAtIndex:2];
    
    CGRect theRect = [contentSView convertRect:imageView.frame fromView:imageView.superview];
    

    
    [popLbl setFrame:CGRectMake(theRect.origin.x-22, theRect.origin.y-20, popLbl.frame.size.width, popLbl.frame.size.height)];
    
    NSInteger v = slider.value+0.5;
    [popLbl setText:[NSString stringWithFormat:@"%ld hour",(long)v]];
    
}




//babyDelegate
-(void)babyDelegate{
    
    __weak typeof(self)weakSelf = self;
    BabyRhythm *rhythm = [[BabyRhythm alloc]init];
    
    
    //设置设备连接成功的委托,同一个baby对象，使用不同的channel切换委托回调
    
    [baby setBlockOnConnectedAtChannel:channelOnPeropheralView block:^(CBCentralManager *central, CBPeripheral *peripheral) {
        [SVProgressHUD showInfoWithStatus:[NSString stringWithFormat:@"设备：%@--连接成功",peripheral.name]];
    }];
    
    //设置发现设备的Services的委托
    [baby setBlockOnDiscoverServicesAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, NSError *error) {
        for (CBService *s in peripheral.services) {
            ///插入section到tableview
            //            [weakSelf insertSectionToTableView:s];
        }
        
        [rhythm beats];
    }];
    //设置发现设service的Characteristics的委托
    [baby setBlockOnDiscoverCharacteristicsAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBService *service, NSError *error) {
        NSLog(@"===service name:%@",service.UUID);
        //插入row到tableview
        //        [weakSelf insertRowToTableView:service];
        
        
        //        if([service.UUID isEqual:@"1912"])
        //           {
        //         NSDictionary * temp = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",8],@"index",weakSelf.characteristic,@"characteristic",weakSelf.currPeripheral,@"currPeripheral",nil];
        //         [weakSelf getRequest:2 requestDic:temp delegate:weakSelf];
        //           }
        
    }];
    //设置读取characteristics的委托
    [baby setBlockOnReadValueForCharacteristicAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
        //硬件返回值
        NSLog(@"--1--characteristic name:%@ value is:%@",characteristics.UUID,characteristics.value);
        Byte * bytes = (Byte *)[characteristics.value bytes];
        
        NSString *newStr = [NSString stringWithFormat:@"%x",bytes[3]&0xff];///16进制数
        NSString        *snStr=@"";//识别码
        if([newStr length]==1)
            snStr = [NSString stringWithFormat:@"%@0%@",snStr,newStr];
        else
            snStr = [NSString stringWithFormat:@"%@%@",snStr,newStr];

        if ([snStr isEqualToString:@"0B"] ) {
 
                // 将值转成16进制
                NSString *newStr = [NSString stringWithFormat:@"%x",bytes[4]&0xff];///16进制数
            NSString * lengthStr = @"";
                if([newStr length]==1)
                    lengthStr = [NSString stringWithFormat:@"%@0%@",lengthStr,newStr];
                else
                    lengthStr = [NSString stringWithFormat:@"%@%@",lengthStr,newStr];
            
            
            //转换类型
            const char *swtr = [lengthStr cStringUsingEncoding:NSASCIIStringEncoding];
            int  nResult=(int)strtol(swtr,NULL,16);
            weakSelf.slider.value = nResult;
        }
    }];
    //设置发现characteristics的descriptors的委托
    [baby setBlockOnDiscoverDescriptorsForCharacteristicAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        NSLog(@"===characteristic name:%@",characteristic.service.UUID);
        for (CBDescriptor *d in characteristic.descriptors) {
            NSLog(@"CBDescriptor name is :%@",d.UUID);
        }
    }];
    //设置读取Descriptor的委托
    [baby setBlockOnReadValueForDescriptorsAtChannel:channelOnPeropheralView block:^(CBPeripheral *peripheral, CBDescriptor *descriptor, NSError *error) {
        NSLog(@"Descriptor name:%@ value is:%@",descriptor.characteristic.UUID, descriptor.value);
    }];
    
    //设置beats break委托
    [rhythm setBlockOnBeatsBreak:^(BabyRhythm *bry) {
        NSLog(@"setBlockOnBeatsBreak call");
        
        //如果完成任务，即可停止beat,返回bry可以省去使用weak rhythm的麻烦
        //        if (<#condition#>) {
        //            [bry beatsOver];
        //        }
        
    }];
    
    //设置beats over委托
    [rhythm setBlockOnBeatsOver:^(BabyRhythm *bry) {
        NSLog(@"setBlockOnBeatsOver call");
    }];
    
    //扫描选项->CBCentralManagerScanOptionAllowDuplicatesKey:忽略同一个Peripheral端的多个发现事件被聚合成一个发现事件
    NSDictionary *scanForPeripheralsWithOptions = @{CBCentralManagerScanOptionAllowDuplicatesKey:@YES};
    /*连接选项->
     CBConnectPeripheralOptionNotifyOnConnectionKey :当应用挂起时，如果有一个连接成功时，如果我们想要系统为指定的peripheral显示一个提示时，就使用这个key值。
     CBConnectPeripheralOptionNotifyOnDisconnectionKey :当应用挂起时，如果连接断开时，如果我们想要系统为指定的peripheral显示一个断开连接的提示时，就使用这个key值。
     CBConnectPeripheralOptionNotifyOnNotificationKey:
     当应用挂起时，使用该key值表示只要接收到给定peripheral端的通知就显示一个提
     */
    NSDictionary *connectOptions = @{CBConnectPeripheralOptionNotifyOnConnectionKey:@YES,
                                     CBConnectPeripheralOptionNotifyOnDisconnectionKey:@YES,
                                     CBConnectPeripheralOptionNotifyOnNotificationKey:@YES};
    
    [baby setBabyOptionsAtChannel:channelOnPeropheralView scanForPeripheralsWithOptions:scanForPeripheralsWithOptions connectPeripheralWithOptions:connectOptions scanForPeripheralsWithServices:nil discoverWithServices:nil discoverWithCharacteristics:nil];
    
}

-(void)StartAction
{
    if(self.currPeripheral != nil &&self.characteristic != nil)
    {
//    baby.channel(channelOnPeropheralView).characteristicDetails(self.currPeripheral,self.characteristic);
    int value2 = week-1;
    if (week-1 == 0) {
        value2 = 7;
    }
    NSDictionary * temp;
    if ([okBtn.titleLabel.text isEqualToString:@"Auto Play"]) {
        
        [okBtn setTitle:@"Stop Play" forState:UIControlStateNormal];
       temp = [NSDictionary dictionaryWithObjectsAndKeys:@"1",@"index",[NSString stringWithFormat:@"%d",time],@"value1",[NSString stringWithFormat:@"%d",value2],@"value2", nil];
        [self getRequest:5 requestDic:temp characteristic:self.characteristic  currPeripheral:self.currPeripheral delegate:self];
    }
    else
    {
        [okBtn setTitle:@"Auto Play" forState:UIControlStateNormal];
        temp = [NSDictionary dictionaryWithObjectsAndKeys:@"7",@"index", nil];
        [self getRequest:2 requestDic:temp characteristic:self.characteristic  currPeripheral:self.currPeripheral delegate:self];

    }
    }
}

-(void)loadAction
{
    if(self.currPeripheral != nil &&self.characteristic != nil)
    {
//    baby.channel(channelOnPeropheralView).characteristicDetails(self.currPeripheral,self.characteristic);
    NSDictionary * temp = [NSDictionary dictionaryWithObjectsAndKeys:@"6",@"index", nil];
    [self getRequest:2 requestDic:temp characteristic:self.characteristic  currPeripheral:self.currPeripheral delegate:self];
    }
}


-(void)loadDataAction:(NSNotification *)notification
{
    self.currPeripheral = mydelegate.currPeripheral;
    self->baby  = mydelegate.baby;
    self.characteristic = [mydelegate.characteristics objectAtIndex:1];
}
@end
